const axios = require("axios");



const findProductByNombre = async (nombre) => {
    const fetchData = await axios.get (`../utils/data${nombre}`);

    const productList = fetchData.data;
    return productList;

}

module.exports = { findProductByNombre};