const express = require('express');
const router = express.Router();
const guitarras = require('./data');

const electricas = guitarras.filter(guitarra => guitarra.categoria === 'eléctrica');
const acusticas = guitarras.filter(guitarra => guitarra.categoria === 'acústica');
const criollas = guitarras.filter(guitarra => guitarra.categoria === 'criolla');

router.get('/electricas', (req, res) => {
  res.json(electricas);
});

router.get('/acusticas', (req, res) => {
  res.json(acusticas);
});

router.get('/criollas', (req, res) => {
  res.json(criollas);
});

module.exports = router;
