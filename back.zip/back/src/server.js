const express = require("express"); // creo el servidor dentro del entorno
const morgan = require("morgan");  // me permite crear logging, muestra la peticion en tiempo real+
const cors = require ("cors"); // me permite hacer peticiones desde cualquier lado
//const categorias = require("../src/service/categorias");
//const router = require("./routes");/*ACTIVAR DESPUES DE HACER LAS RUTAS*/

// la const server, va a ser mi servidor

const server = express();


server.use(express.json()); // me convierte el formato JSON a un formato que JS puede leer
server.use(cors()); // me permite hacer peticiones desde cualquier lado
server.use(morgan("dev"));

//server.use(router);




module.exports = server;

