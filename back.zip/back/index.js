const server = require ("./src/server");
//const {conn} = require ("./src/DB_connection");/**Activar despues de hacer la DB */


server.listen(3010, () => { //Este puerto me permite, por el metodo .listen(), indicar desde que puerto hago las peticiones en mi PC
    console.log("Server listening on port 3010");
   });